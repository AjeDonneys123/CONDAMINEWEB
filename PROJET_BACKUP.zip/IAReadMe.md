# GUIDE IA - PROJET CONDAMINE

- **Architecture** : Vanilla JS / Express.
- **Global** : `window.api` et `window.state` sont les seuls services.
- **Pas d'imports relatifs** dans les sous-modules JS.
- **Updates** : Utiliser `apply.js` avec le format `