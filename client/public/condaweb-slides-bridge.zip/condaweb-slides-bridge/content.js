// CondaWeb Slides Bridge - Content Script injecté dans Google Slides (100% Trusted Types Compliant)

(function () {
  const BRIDGE_VERSION = '1.0.44';
    // Older bridge versions stored `true` here.  Do not let that old marker
    // block an upgraded content script: it must replace the old click handler
    // without requiring the teacher to hunt for an extension reload.
    if (window.__CONDA_BRIDGE_ACTIVE__ === BRIDGE_VERSION) {
        console.log('[CondaWeb Bridge] Déjà actif sur cette page Google Slides.');
        return;
    }
    // When Chrome injects an upgraded bridge into an already-open Slides tab,
    // stop every timer/listener owned by the previous version first. Without
    // this, the old script keeps sending messages to the now-invalid extension
    // context and makes the badge appear randomly disconnected.
    try { window.__CONDA_BRIDGE_SESSION__?.dispose?.(); } catch (_) {}
    window.__CONDA_BRIDGE_ACTIVE__ = BRIDGE_VERSION;

    console.log('[CondaWeb Bridge] 🚀 Initialisation dans Google Slides...');

    let activeClassId = '';
    let activeClassName = '';
    let isConnected = false;
    let lastSeenSlideHash = '';
    let lastHandledAnimationVersion = 0;
    let lastHandledPlayVersion = 0;
    let lastHandledPauseVersion = 0;
    let overlayRoot = null;
    const displayedAlertIds = new Set();
    const replayableAlertIds = new Set();
    const dismissedPersistentNoticeIds = new Set();
    let lastScoreAlertSyncVersion = 0;
    let scoreAlertSyncVersionKnown = false;
    let lastPlanSignature = '';
    let lastLiveClassroomSignature = '';
    let badgeDismissedForPage = false;

    let currentClassroomState = null;
    let currentRemoteState = null;
    let currentSlideControl = null;
    let controlMenuOpen = false;
    let controlMenuRows = [];
    let classMenuOpen = false;
    let classMenuRows = [];
    let currentSlideControlDetails = null;
    let syncInFlight = false;
    let manualConnectInFlight = false;
    let consecutiveSyncFailures = 0;
  let hasSuccessfulClassSync = false;
  let lastSuccessfulClassSyncAt = 0;
  let nextAutoConnectAt = 0;
  // A presentation opened directly in Google Slides is not necessarily linked
  // to a CondaWeb course.  Keep that state stable: retrying every second made
  // the badge jump between the dock and the top-left corner.
  let presentationAssociationMissing = false;
  let unlinkedPresentationId = '';
  let presentationAssociationNoticeLogged = false;
  let presentationAssociationBadgeShown = false;
  let bridgeStopped = false;
    let syncTimerId = null;
    let domObserver = null;
    let bridgePort = null;
    let proxyRequestSequence = 0;
    const pendingProxyRequests = new Map();
    // The classroom state contains the two critical live features: score
    // notifications and the mirrored seating plan. Keep it independent from
    // the heavier presentation/video state.
    // The bridge now polls only lightweight note/plan visibility state while
    // the plan is closed. One request per second keeps grade notices quick
    // without starving Google Slides or the phone.
    const CLASSROOM_POLL_MS = 1000;

    const bridgeSession = {
        version: BRIDGE_VERSION,
        dispose() {
            bridgeStopped = true;
            if (syncTimerId) window.clearInterval(syncTimerId);
            syncTimerId = null;
            if (timerIntervalId) clearInterval(timerIntervalId);
            timerIntervalId = null;
            if (timerAlarmIntervalId) clearInterval(timerAlarmIntervalId);
            timerAlarmIntervalId = null;
            if (timerAudioCtx) {
                try { timerAudioCtx.close(); } catch (_) {}
                timerAudioCtx = null;
            }
            closeBridgePort(new Error('Bridge remplacé'));
            try { domObserver?.disconnect(); } catch (_) {}
            document.removeEventListener('click', onBadgeCapture, true);
            document.removeEventListener('fullscreenchange', onFullscreenChange);
            if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
                chrome.storage.onChanged.removeListener(onStorageChanged);
            }
        }
    };
    window.__CONDA_BRIDGE_SESSION__ = bridgeSession;

function isExtensionContextError(error) {
  return /extension context invalidated|extension runtime non disponible|message channel closed|receiving end does not exist|listener indicated an asynchronous response/i.test(String(error?.message || error || ''));
}

function isPresentationAssociationMissingError(error) {
  const message = String(error?.message || error || '').toLocaleLowerCase('fr-FR');
  return message.includes('présentation condaweb non associée')
    || message.includes('presentation condaweb non associee')
    || message.includes('ouvrez-la depuis la page cours');
}

function showPresentationUnlinkedBadge() {
  const text = 'Présentation non liée — ouvre-la depuis Cours';
  isConnected = false;
  const currentLabel = document.getElementById('conda-bridge-badge-label')?.textContent;
  if (presentationAssociationBadgeShown && currentLabel === text) return;
  presentationAssociationBadgeShown = true;
  renderBadge(false, text);
}

    function stopForExtensionReload(error) {
        if (bridgeStopped) return;
        // Chrome invalidates the old content-script world while an extension
        // reloads. This is expected, so it must not pollute the error page.
        console.info('[CondaWeb Bridge] ancien contexte arrêté après rechargement de l’extension.');
        bridgeSession.dispose();
        // The newly injected script recreates the badge and overlays.
    }

    function closeBridgePort(error) {
        const port = bridgePort;
        bridgePort = null;
        if (port) {
            try { port.disconnect(); } catch (_) {}
        }
        pendingProxyRequests.forEach(({ reject, timer }) => {
            window.clearTimeout(timer);
            reject(error);
        });
        pendingProxyRequests.clear();
    }

    function ensureBridgePort() {
        if (bridgePort) return bridgePort;
        if (bridgeStopped || typeof chrome === 'undefined' || !chrome.runtime?.id) {
            throw new Error('Extension runtime non disponible');
        }

        const port = chrome.runtime.connect({ name: 'condaweb-api-proxy-v1' });
        bridgePort = port;
        port.onMessage.addListener((response) => {
            const requestId = String(response?.requestId || '');
            const pending = pendingProxyRequests.get(requestId);
            if (!pending) return;
            pendingProxyRequests.delete(requestId);
            window.clearTimeout(pending.timer);
            if (response?.ok) pending.resolve(response.data);
            else pending.reject(new Error(response?.error || `Erreur CondaWeb HTTP ${response?.status || 'inconnue'}`));
        });
        port.onDisconnect.addListener(() => {
            if (bridgePort !== port) return;
            const error = chrome.runtime?.lastError || new Error('Port CondaWeb fermé');
            if (isExtensionContextError(error)) stopForExtensionReload(error);
            else closeBridgePort(error);
        });
        console.info('[CondaWeb Bridge] port de synchronisation ouvert');
        return port;
    }

    // Some already-open Slides tabs can still carry the click handler from an
    // older bridge version (the one that opened a prompt containing a class
    // ID). Capture the click before that handler runs. This works as soon as
    // this version is injected; it does not depend on a successful API call.
    function onBadgeCapture(event) {
        const target = event.target instanceof Element
            ? event.target.closest('#conda-bridge-badge')
            : null;
        if (!target) return;
        const dismissButton = event.target instanceof Element
            ? event.target.closest('.conda-bridge-dismiss')
            : null;
        if (dismissButton) {
            event.preventDefault();
            event.stopImmediatePropagation();
            badgeDismissedForPage = true;
            target.remove();
            console.info('[CondaWeb Bridge] badge de connexion masqué pour cette page');
            return;
        }
        // The small grip is reserved for moving the badge. It must never
        // trigger a synchronization while the teacher is positioning it.
        if (event.target instanceof Element && event.target.closest('.conda-bridge-drag-handle')) return;
        event.preventDefault();
        event.stopImmediatePropagation();

        const isInDock = Boolean(target.closest('.conda-slide-control-dock'));
        if (isConnected && isInDock) {
            console.info('[CondaWeb Bridge] clic badge connecté en bas : menu des classes');
            void toggleClassSelectionMenu();
            return;
        }

        console.info('[CondaWeb Bridge] clic badge : reconnexion demandée');
        void connectAndSynchronizeNow();
    }
    document.addEventListener('click', onBadgeCapture, true);

    document.addEventListener('click', (event) => {
        const target = event.target instanceof Element ? event.target : null;
        if (!target) return;
        let changed = false;
        if (classMenuOpen && !target.closest('.conda-slide-class-menu') && !target.closest('#conda-bridge-badge')) {
            classMenuOpen = false;
            changed = true;
        }
        if (controlMenuOpen && !target.closest('.conda-slide-control-menu') && !target.closest('.conda-slide-control-add')) {
            controlMenuOpen = false;
            changed = true;
        }
        if (changed) {
            renderAllOverlays();
        }
    });

    const oldBadge = document.getElementById('conda-bridge-badge');
    if (oldBadge) oldBadge.onclick = null;

    function consumeScoreAlertReplay(classData, { replayOnInitial = false } = {}) {
        const scoreAlertSyncVersion = Number(classData?.scoreAlertSyncVersion || 0);
        const replayId = String(classData?.scoreAlertReplayId || '');
        const isNewReplay = !scoreAlertSyncVersionKnown
            ? replayOnInitial && scoreAlertSyncVersion > 0
            : scoreAlertSyncVersion > lastScoreAlertSyncVersion;

        if (isNewReplay && replayId) {
            displayedAlertIds.delete(replayId);
            replayableAlertIds.add(replayId);
            console.info('[CondaWeb Bridge notes] rediffusion demandée', { replayId, scoreAlertSyncVersion });
        }
        lastScoreAlertSyncVersion = Math.max(lastScoreAlertSyncVersion, scoreAlertSyncVersion);
        scoreAlertSyncVersionKnown = true;
    }

    function storeResolvedClass(classData) {
        const resolvedId = String(classData?._id || classData?.id || '');
        if (!resolvedId || resolvedId === activeClassId) return;
        const previousId = activeClassId;
        activeClassId = resolvedId;
        activeClassName = String(classData?.name || activeClassName || 'Classe active');
        console.info('[CondaWeb Bridge] classe réparée pour le tableau', { previousId, activeClassId, activeClassName });
    }

    async function fetchClassroomState({ manual = false, forcePlan = false } = {}) {
        if (!activeClassId) throw new Error('Aucune classe associée');
        const marker = manual ? `manual=${Date.now()}` : `live=${Date.now()}`;
        const name = String(activeClassName || '').trim();
        const suffix = name ? `&className=${encodeURIComponent(name)}` : '';
        const wantsPlan = forcePlan || currentClassroomState?.classPlanVisible === true;
        const planSuffix = wantsPlan ? '&includePlan=1' : '';
        const data = await callCondaApi(`/api/classroom/bridge-state/${encodeURIComponent(activeClassId)}?${marker}${suffix}${planSuffix}`);
        storeResolvedClass(data);
        const planSignature = `${data?._id || activeClassId}:${data?.planStudentCount || data?.planStudents?.length || 0}:${data?.layout?.cols || 0}:${data?.layout?.rows || 0}`;
        if (planSignature !== lastPlanSignature) {
            lastPlanSignature = planSignature;
            console.info('[CondaWeb Bridge plan] état reçu', {
                classId: data?._id || activeClassId,
                students: Number(data?.planStudentCount ?? data?.planStudents?.length ?? 0),
                cols: data?.layout?.cols,
                rows: data?.layout?.rows
            });
        }
        return data;
    }

    function resolveCurrentVideo(remoteData = currentRemoteState) {
        const remote = remoteData?.remote || {};
        if (remoteData?.currentVideo) return remoteData.currentVideo;
        if (remote?.currentVideo) return remote.currentVideo;
        const slides = Array.isArray(remoteData?.videoSlides) ? remoteData.videoSlides : [];
        const requestedNumber = Math.max(1, Number(remote.slideIndex || 0) + 1);
        let slide = slides.find((item) => Number(item?.slideNumber) === requestedNumber);
        if (!slide) {
            const configured = slides.filter((item) => Array.isArray(item?.scenes)
                && item.scenes.some((scene) => Array.isArray(scene?.sequences) && scene.sequences.length));
            if (configured.length === 1) slide = configured[0];
        }
        const scenes = Array.isArray(slide?.scenes) ? slide.scenes : [];
        const scene = scenes[Math.max(0, Math.min(scenes.length - 1, Number(remote.sceneIndex || 0)))];
        const sequences = Array.isArray(scene?.sequences) ? scene.sequences : [];
        return sequences[Math.max(0, Math.min(sequences.length - 1, Number(remote.sequenceIndex || 0)))] || null;
    }

    function sendCourseCommand(action, extra = {}) {
        if (!currentCourseId) return Promise.reject(new Error('Aucun cours CondaWeb actif'));
        return callCondaApi(`/api/courses/${currentCourseId}/presentation-remote/command`, {
            method: 'POST',
            body: { action, ...extra }
        });
    }

    function reportBufferStatus(bufferPct, isReady = false) {
        if (!currentCourseId || !currentRemoteState?.remote) return Promise.resolve();
        const remote = currentRemoteState.remote;
        return callCondaApi(`/api/courses/${currentCourseId}/presentation-remote/buffer-status`, {
            method: 'POST',
            body: {
                slideIndex: Number(remote.slideIndex || 0),
                sceneIndex: Number(remote.sceneIndex || 0),
                sequenceIndex: Number(remote.sequenceIndex || 0),
                bufferPct: Math.max(0, Math.min(100, Math.round(Number(bufferPct || 0)))),
                isReady
            }
        }).catch(() => {});
    }

    // 1. Initialiser le conteneur d'overlay (avec styles en ligne forcés)
    function ensureOverlayRoot() {
        if (!overlayRoot || !document.contains(overlayRoot)) {
            overlayRoot = document.getElementById('condaweb-overlay-root');
            if (!overlayRoot) {
                overlayRoot = document.createElement('div');
                overlayRoot.id = 'condaweb-overlay-root';
                overlayRoot.style.cssText = 'position: fixed !important; top: 0 !important; left: 0 !important; width: 100vw !important; height: 100vh !important; pointer-events: none !important; z-index: 2147483647 !important; overflow: hidden !important;';
            }
            const parent = document.fullscreenElement || document.body || document.documentElement;
            if (parent && !parent.contains(overlayRoot)) {
                parent.appendChild(overlayRoot);
            }
        }
        return overlayRoot;
    }

    // Gérer le passage en plein écran (Diaporama)
    function onFullscreenChange() {
        if (overlayRoot) {
            const targetParent = document.fullscreenElement || document.body || document.documentElement;
            if (targetParent) targetParent.appendChild(overlayRoot);
        }
    }
    document.addEventListener('fullscreenchange', onFullscreenChange);

    // 2. Appel sécurisé via un port persistant du service worker. Contrairement
    // à sendMessage/sendResponse, ce canal ne se ferme pas entre le fetch et sa
    // réponse quand Chrome met le worker en veille.
    function callCondaApi(path, options = {}) {
        return new Promise((resolve, reject) => {
            let requestId = '';
            if (bridgeStopped) {
                return reject(new Error('Extension runtime non disponible'));
            }
            try {
                const port = ensureBridgePort();
                requestId = `${Date.now()}-${++proxyRequestSequence}`;
                const timer = window.setTimeout(() => {
                    const pending = pendingProxyRequests.get(requestId);
                    if (!pending) return;
                    pendingProxyRequests.delete(requestId);
                    reject(new Error('Délai de réponse CondaWeb dépassé'));
                }, 15000);
                pendingProxyRequests.set(requestId, { resolve, reject, timer });
                port.postMessage({
                    type: 'PROXY_FETCH',
                    requestId,
                    path,
                    method: options.method || 'GET',
                    body: options.body
                });
            } catch (error) {
                const pending = pendingProxyRequests.get(requestId);
                if (pending) {
                    pendingProxyRequests.delete(requestId);
                    window.clearTimeout(pending.timer);
                }
                if (isExtensionContextError(error)) stopForExtensionReload(error);
                reject(error);
            }
        });
    }

    // 3. La classe n'est volontairement plus reprise depuis le stockage de
    // l'extension. Ce stockage est partagé par tous les onglets Google Slides
    // et mélangeait par exemple 5A et 5D. La page CondaWeb qui ouvre Slides
    // transmet désormais le couple précis cours + classe dans l'URL.
    function loadConfig() {
        // Kept as a no-op for older initialization code.
    }
    let currentCourseId = '';
    let currentCourseTitle = '';
    let hasAutoConnected = false;

    loadConfig();
    function onStorageChanged(changes, areaName) {
            // Intentionally ignored: a selection in the popup or another
            // Slides tab must never change this tab's classroom.
    }
    if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
        chrome.storage.onChanged.addListener(onStorageChanged);
    }

    // Récupérer les métadonnées de la présentation Google Slides
    function getSlideInfo() {
        const pathMatch = window.location.pathname.match(/\/presentation\/d\/([a-zA-Z0-9_-]+)/);
        const presentationId = pathMatch ? pathMatch[1] : '';
        const titleInput = document.querySelector('.docs-title-input') || document.querySelector('[aria-label="Titre de la présentation"]');
        const title = (titleInput?.value || document.title || '')
            .replace(/\s*-\s*Google\s*(Présentations|Slides|Documentos).*/i, '')
            .trim();

        const hash = window.location.hash || '';
        const hashMatch = hash.match(/#slide=id\.([a-zA-Z0-9_-]+)/);
        const slideObjectId = hashMatch ? hashMatch[1] : '';

        const query = new URLSearchParams(window.location.search);
        return {
            presentationId,
            title,
            slideObjectId,
            bridgeCourseId: String(query.get('condaCourseId') || '').trim(),
            bridgeClassId: String(query.get('condaClassId') || '').trim()
        };
    }

    // Auto-connexion intelligente : relie automatiquement le diaporama Google au bon cours CondaWeb
async function autoConnectPresentation({ replaceClass = false, force = false } = {}) {
  const { presentationId, title, slideObjectId, bridgeCourseId, bridgeClassId } = getSlideInfo();
  if (!presentationId && !title) return false;

  // A presentation opened directly in Google Slides has no CondaWeb context.
  // Do not keep calling the API every few seconds in that case: it made the
  // connector blink and needlessly flooded the server.
  if (unlinkedPresentationId && unlinkedPresentationId !== presentationId) {
    presentationAssociationMissing = false;
    unlinkedPresentationId = '';
    presentationAssociationNoticeLogged = false;
    presentationAssociationBadgeShown = false;
    nextAutoConnectAt = 0;
  }
  if (presentationAssociationMissing
    && unlinkedPresentationId === presentationId
    && !force
    && !replaceClass) {
    showPresentationUnlinkedBadge();
    return false;
  }

  try {
            const data = await callCondaApi('/api/courses/presentation-remote/auto-connect', {
                method: 'POST',
                body: {
                    presentationId,
                    title,
                    slideIndex: 0,
                    // The Slides bridge now mirrors only plan/notes. Avoid
                    // transferring video scenes on every connection.
                    light: true,
                    // The browser tab owns this pair. It is supplied by the
                    // CondaWeb page that launched the presentation, so two
                    // classes of the same level can never be mixed.
                    courseId: bridgeCourseId,
                    classId: bridgeClassId
                }
            });
    if (data?.ok && data.courseId) {
      presentationAssociationMissing = false;
      unlinkedPresentationId = '';
      presentationAssociationNoticeLogged = false;
      presentationAssociationBadgeShown = false;
      currentCourseId = data.courseId;
                currentCourseTitle = data.title || title;
                const classChanged = Boolean(data.classId) && String(data.classId) !== activeClassId;
                if (data.classId) activeClassId = String(data.classId);
                if (data.className) activeClassName = String(data.className);
                isConnected = true;
                hasAutoConnected = true;

                const displayTitle = (currentCourseTitle.length > 20 ? currentCourseTitle.slice(0, 18) + '…' : currentCourseTitle);
                renderBadge(true, `${displayTitle} (${activeClassName})`);
                console.log(`[CondaWeb Bridge] 🎯 Auto-connecté au cours : "${currentCourseTitle}" pour la classe ${activeClassName}`);
                console.log('[CondaWeb Bridge Debug]', {
                    presentationId,
                    slideObjectId,
                    courseId: data.courseId,
                    classId: data.classId,
                    remoteActive: data.remote?.active,
                    slideIndex: data.remote?.slideIndex,
                    sceneIndex: data.remote?.sceneIndex,
                    sequenceIndex: data.remote?.sequenceIndex,
                    videoSlidesCount: data.videoSlides?.length || 0
                });
                return true;
            }
  } catch (e) {
    if (isPresentationAssociationMissingError(e)) {
      presentationAssociationMissing = true;
      unlinkedPresentationId = presentationId;
      // Stop periodic reconnection attempts until the page is opened from
      // CondaWeb (or the user explicitly requests a new connection).
      nextAutoConnectAt = Number.POSITIVE_INFINITY;
      if (!presentationAssociationNoticeLogged) {
        console.info('[CondaWeb Bridge] Présentation non liée à CondaWeb : ouvre-la depuis la page Cours pour connecter le plan, les alertes et les contrôles.', {
          presentationId,
          title,
        });
      }
      presentationAssociationNoticeLogged = true;
      showPresentationUnlinkedBadge();
      return false;
    }
    if (isExtensionContextError(e) || bridgeStopped) return false;
            console.warn('[CondaWeb Bridge] Auto-connect en attente…', e.message);
        }
        return false;
    }

    // This is the explicit action behind the badge.  It does not wait for the
    // background poll: it reconnects the presentation, verifies the class and
    // sends the current Google slide to the phone immediately.
    async function connectAndSynchronizeNow() {
        if (manualConnectInFlight) return;
        manualConnectInFlight = true;
        renderBadge(false, 'Connexion et synchronisation…');
        console.info('[CondaWeb Bridge] synchronisation manuelle demandée');
        try {
            await autoConnectPresentation({ replaceClass: true });
            if (!activeClassId) throw new Error('Aucune classe associée à cette présentation');

            const classData = await fetchClassroomState({ manual: true });
            currentClassroomState = classData;
            // A manual reconnect must not replay a score change from a
            // previous lesson. Only changes received after this connection
            // are shown on Slides.
            consumeScoreAlertReplay(classData, { replayOnInitial: false });
            isConnected = true;
            hasSuccessfulClassSync = true;
            consecutiveSyncFailures = 0;
            renderAllOverlays();
            console.info('[CondaWeb Bridge] synchronisation manuelle terminée', { activeClassId, currentCourseId });
        } catch (error) {
            if (isExtensionContextError(error) || bridgeStopped) return;
            isConnected = false;
            console.error('[CondaWeb Bridge] synchronisation manuelle impossible', {
                message: error?.message || String(error), activeClassId, currentCourseId
            });
            renderBadge(false, 'Connexion impossible — clique pour réessayer');
        } finally {
            manualConnectInFlight = false;
        }
    }

    // Google Slides owns media playback. The bridge deliberately does not
    // synchronize scenes or videos when the current slide changes.
    async function checkCurrentSlide() {
        const hash = window.location.hash || '';
        if (hash !== lastSeenSlideHash) {
            lastSeenSlideHash = hash;
            console.debug('[CondaWeb Bridge] slide Google détectée (média géré par Google Slides)');
        }
    }

    // Controls are opened only after an explicit teacher choice. We do not
    // persist or reload a control for a slide, so opening Slides can never
    // cause an exam to appear by itself.
    async function openSelectedControl(choice) {
        if (!currentCourseId) {
            alert('La présentation CondaWeb est encore en cours de connexion. Réessaie dans une seconde.');
            return;
        }
        try {
            if (!choice?._id) return;
            currentSlideControl = { controlId: String(choice._id), controlTitle: String(choice.title || 'Contrôle') };
            currentSlideControlDetails = choice;
            controlMenuOpen = false;
            controlMenuRows = [];
            console.info('[CondaWeb Bridge contrôle] ouverture demandée par le professeur', { courseId: currentCourseId, controlId: choice._id, title: choice.title });
            renderAllOverlays();
            void openControlWindows();
        } catch (error) {
            console.error('[CondaWeb Bridge contrôle] ouverture impossible', error?.message || String(error));
            alert('Impossible d’ouvrir ce contrôle.');
        }
    }

    async function openControlsMenu() {
        try {
            const rows = await callCondaApi('/api/controls/all');
            const classKey = String(activeClassName || '').replace(/\s/g, '').toUpperCase();
            controlMenuRows = (Array.isArray(rows) ? rows : []).filter((control) => {
                if (control?.active === false) return false;
                const targets = Array.isArray(control?.targetClassrooms) ? control.targetClassrooms : [];
                return !targets.length || targets.some((target) => String(target || '').replace(/\s/g, '').toUpperCase() === classKey);
            });
            controlMenuOpen = true;
            console.info('[CondaWeb Bridge contrôle] menu ouvert', { controls: controlMenuRows.length, className: activeClassName });
            renderAllOverlays();
        } catch (error) {
            console.error('[CondaWeb Bridge contrôle] liste impossible', error?.message || String(error));
            alert('Impossible de charger les contrôles disponibles.');
        }
    }

    async function toggleClassSelectionMenu() {
        if (classMenuOpen) {
            classMenuOpen = false;
            renderAllOverlays();
            return;
        }
        controlMenuOpen = false;

        try {
            const config = await callCondaApi('/api/auth/config');
            const classes = Array.isArray(config) ? config : (config?.classrooms || []);
            classMenuRows = Array.isArray(classes) ? classes : [];
            classMenuOpen = true;
            console.info('[CondaWeb Bridge classe] menu ouvert', { count: classMenuRows.length, current: activeClassName });
            renderAllOverlays();
        } catch (error) {
            console.error('[CondaWeb Bridge classe] chargement impossible', error?.message || String(error));
            alert('Impossible de charger la liste des classes.');
        }
    }

    async function selectAnotherClass(cls) {
        const newClassId = String(cls?._id || cls?.id || '');
        const newClassName = String(cls?.name || cls?.title || 'Classe');
        if (!newClassId) return;

        classMenuOpen = false;
        console.info('[CondaWeb Bridge] Bascule vers la classe demandée :', { newClassId, newClassName });
        activeClassId = newClassId;
        activeClassName = newClassName;

        try {
            if (typeof chrome !== 'undefined' && chrome.storage?.local) {
                chrome.storage.local.set({ activeClassId: newClassId, activeClassName: newClassName });
            }
        } catch (_) {}

        const { presentationId, title } = getSlideInfo();
        try {
            if (presentationId) {
                const autoConnectPayload = {
                    presentationId,
                    title,
                    slideIndex: 0,
                    light: true,
                    classId: newClassId,
                    courseId: currentCourseId
                };
                const data = await callCondaApi('/api/courses/presentation-remote/auto-connect', {
                    method: 'POST',
                    body: autoConnectPayload
                });
                if (data?.ok) {
                    if (data.courseId) currentCourseId = data.courseId;
                    if (data.title) currentCourseTitle = data.title;
                }
            }

            const classData = await fetchClassroomState({ manual: true });
            currentClassroomState = classData;
            consumeScoreAlertReplay(classData, { replayOnInitial: false });
            isConnected = true;
            hasSuccessfulClassSync = true;
            consecutiveSyncFailures = 0;

            const displayTitle = currentCourseTitle ? (currentCourseTitle.length > 20 ? currentCourseTitle.slice(0, 18) + '…' : currentCourseTitle) : 'Connecté';
            renderBadge(true, `${displayTitle} (${activeClassName})`);
            renderAllOverlays();
            console.info('[CondaWeb Bridge] Bascule réussie vers :', activeClassName);
        } catch (error) {
            console.error('[CondaWeb Bridge] Erreur lors de la bascule de classe', error?.message || String(error));
            renderAllOverlays();
        }
    }

    async function togglePlanFromSlides() {
        const nextVisible = currentClassroomState?.classPlanVisible !== true;
        console.info('[CondaWeb Bridge plan] Clic bouton Plan depuis Slides', { nextVisible, activeClassId });

        // 1. Mise à jour immédiate optimiste de l'interface locale
        if (currentClassroomState) {
            currentClassroomState.classPlanVisible = nextVisible;
        } else {
            currentClassroomState = { classPlanVisible: nextVisible };
        }
        renderAllOverlays();

        // 2. Synchronisation serveur
        if (activeClassId) {
            try {
                await callCondaApi(`/api/classroom/${encodeURIComponent(activeClassId)}/bridge-plan`, {
                    method: 'PUT', body: { visible: nextVisible }
                });
                currentClassroomState = await fetchClassroomState({ manual: true, forcePlan: nextVisible });
                renderAllOverlays();
            } catch (error) {
                console.error('[CondaWeb Bridge plan] modification impossible', error?.message || String(error));
            }
        }
    }

    function getControlPublicUrl(controlId) {
        return new Promise((resolve) => {
            try {
                chrome.storage.local.get(['condaServerUrl'], ({ condaServerUrl }) => {
                    const server = String(condaServerUrl || 'https://condaweb.vercel.app');
                    const appUrl = server.replace(/:3000\/?$/, ':5173');
                    resolve(`${appUrl.replace(/\/$/, '')}/?control=${encodeURIComponent(controlId)}`);
                });
            } catch (_) { resolve(`https://condaweb.vercel.app/?control=${encodeURIComponent(controlId)}`); }
        });
    }

    async function getCurrentControlDetails() {
        if (!currentSlideControl?.controlId) return null;
        if (String(currentSlideControlDetails?._id || '') === String(currentSlideControl.controlId)) return currentSlideControlDetails;
        const rows = await callCondaApi('/api/controls/all');
        currentSlideControlDetails = (Array.isArray(rows) ? rows : [])
            .find((row) => String(row?._id || '') === String(currentSlideControl.controlId)) || null;
        return currentSlideControlDetails;
    }

    function makeFloatingControlWindow(root, className, headerText) {
        root.querySelector(`.${className}`)?.remove();
        const panel = document.createElement('section');
        panel.className = className;
        const header = document.createElement('header');
        const label = document.createElement('span');
        label.textContent = headerText;
        const close = document.createElement('button');
        close.type = 'button';
        close.textContent = '×';
        close.setAttribute('aria-label', 'Fermer cette fenêtre');
        // Do not let Google Slides or the draggable header consume the close
        // gesture. Pointerdown is stopped before the header starts dragging.
        close.onpointerdown = (event) => { event.stopPropagation(); };
        close.onpointerup = (event) => { event.preventDefault(); event.stopPropagation(); panel.remove(); };
        close.onclick = (event) => { event.preventDefault(); event.stopPropagation(); panel.remove(); };
        header.append(label, close);
        panel.appendChild(header);
        root.appendChild(panel);

        let dragStart = null;
        header.onpointerdown = (event) => {
            if (event.target?.closest?.('button')) return;
            event.preventDefault();
            event.stopPropagation();
            const rect = panel.getBoundingClientRect();
            panel.style.left = `${rect.left}px`;
            panel.style.top = `${rect.top}px`;
            panel.style.transform = 'none';
            dragStart = { x: event.clientX, y: event.clientY, left: rect.left, top: rect.top };
            header.setPointerCapture?.(event.pointerId);
        };
        header.onpointermove = (event) => {
            if (!dragStart) return;
            panel.style.left = `${Math.max(8, dragStart.left + event.clientX - dragStart.x)}px`;
            panel.style.top = `${Math.max(8, dragStart.top + event.clientY - dragStart.y)}px`;
        };
        header.onpointerup = () => { dragStart = null; };
        header.onpointercancel = () => { dragStart = null; };
        return panel;
    }

    function fillProjectedControl(panel, control) {
        // Les mots entre guillemets servent à définir les trous côté professeur.
        // Ils ne doivent jamais révéler la réponse aux élèves au tableau.
        const publicPrompt = (value) => String(value || '')
            .replace(/["“«][^"”»]*["”»]/g, '__________')
            .replace(/\s{2,}/g, ' ')
            .trim();
        const title = document.createElement('h2');
        title.textContent = String(control?.title || currentSlideControl?.controlTitle || 'Contrôle');
        panel.appendChild(title);
        const intro = document.createElement('p');
        intro.textContent = 'Répondez sur feuille ou scannez le QR code.';
        panel.appendChild(intro);
        const questions = document.createElement('div');
        questions.className = 'conda-projected-control-questions';
        const items = Array.isArray(control?.items) ? control.items : [];
        if (!items.length) {
            const empty = document.createElement('p');
            empty.textContent = 'Le contenu du contrôle est indisponible pour le moment.';
            questions.appendChild(empty);
        }
        items.forEach((item, index) => {
            const question = document.createElement('article');
            const number = document.createElement('strong');
            number.textContent = `${index + 1}. ${String(item?.lessonTitle || 'Question')}`;
            const prompt = document.createElement('p');
            prompt.textContent = publicPrompt(item?.prompt);
            question.append(number, prompt);
            const choices = Array.isArray(item?.choices) ? item.choices : [];
            if (choices.length) {
                const list = document.createElement('ol');
                choices.forEach((choice) => {
                    const row = document.createElement('li');
                    row.textContent = String(choice || '');
                    list.appendChild(row);
                });
                question.appendChild(list);
            }
            questions.appendChild(question);
        });
        panel.appendChild(questions);
    }

    async function openControlWindows() {
        if (!currentSlideControl?.controlId) return;
        const root = ensureOverlayRoot();
        const controlPanel = makeFloatingControlWindow(root, 'conda-projected-control-window', '📝 CONTRÔLE · glisser / redimensionner');
        try {
            fillProjectedControl(controlPanel, await getCurrentControlDetails());
        } catch (error) {
            console.error('[CondaWeb Bridge contrôle] contenu impossible', error?.message || String(error));
            fillProjectedControl(controlPanel, null);
        }

        const url = await getControlPublicUrl(currentSlideControl.controlId);
        const qrPanel = makeFloatingControlWindow(root, 'conda-control-qr-window', '📱 QR DU CONTRÔLE · glisser / redimensionner');
        const title = document.createElement('strong');
        title.textContent = String(currentSlideControl.controlTitle || 'Contrôle');
        const qr = document.createElement('img');
        qr.src = `https://api.qrserver.com/v1/create-qr-code/?size=320x320&data=${encodeURIComponent(url)}`;
        qr.alt = `QR code : ${currentSlideControl.controlTitle || 'Contrôle'}`;
        const note = document.createElement('small');
        note.textContent = 'Les élèves scannent ce QR ; les autres répondent sur feuille.';
        qrPanel.append(title, qr, note);
        console.info('[CondaWeb Bridge contrôle] contrôle et QR ouverts dans Slides', { controlId: currentSlideControl.controlId });
    }

    // 5. Boucle principale de synchronisation avec CondaWeb
    async function syncWithCondaWeb() {
        if (bridgeStopped || syncInFlight) return;
        syncInFlight = true;
        try {
        if (!hasAutoConnected && Date.now() >= nextAutoConnectAt) {
            const connected = await autoConnectPresentation();
            if (!connected && presentationAssociationMissing) {
                showPresentationUnlinkedBadge();
                return;
            }
            // Never hammer the API while the server is starting or waking up.
            if (!connected) nextAutoConnectAt = Date.now() + 5000;
        }

        checkCurrentSlide();

        if (!activeClassId) {
            renderBadge(false, 'En attente de classe…');
            return;
        }

        try {
            // Récupère l'état de la classe (alertes élèves, avertissements)
            const classData = await fetchClassroomState();
            consumeScoreAlertReplay(classData, { replayOnInitial: false });
            currentClassroomState = classData;
            const latestAlert = Array.isArray(classData?.activeScoreAlerts)
                ? classData.activeScoreAlerts[classData.activeScoreAlerts.length - 1]
                : null;
            const liveSignature = [
                classData?.scoreAlertSyncVersion || 0,
                latestAlert?.id || '',
                classData?.activeStudentHighlightTime || '',
                Array.isArray(classData?.activeHourWarnings) ? classData.activeHourWarnings.map((row) => row?.studentId || row?.name || '').join('|') : ''
            ].join(':');
            if (liveSignature !== lastLiveClassroomSignature) {
                lastLiveClassroomSignature = liveSignature;
                console.info('[CondaWeb Bridge direct] état reçu', {
                    classId: classData?._id || '',
                    className: classData?.name || '',
                    scoreAlertVersion: Number(classData?.scoreAlertSyncVersion || 0),
                    latestAlert,
                    highlight: classData?.activeStudentHighlight || '',
                    hourWarnings: Array.isArray(classData?.activeHourWarnings) ? classData.activeHourWarnings.length : 0
                });
            }
            isConnected = true;
            hasSuccessfulClassSync = true;
            consecutiveSyncFailures = 0;
            lastSuccessfulClassSyncAt = Date.now();
            // Les fonctions de l'onglet Classe ne dépendent pas d'un cours actif.
            isConnected = Boolean(classData?._id || classData?.id);
            // Render the plan and grade alert immediately. Media is entirely
            // handled by Google Slides and causes no bridge request.
            renderAllOverlays();

        } catch (err) {
            if (isExtensionContextError(err)) return;
            consecutiveSyncFailures += 1;
            console.warn('[CondaWeb Bridge] état de classe indisponible', {
                classId: activeClassId,
                failures: consecutiveSyncFailures,
                message: err?.message || String(err)
            });
            // A single slow request is not a real disconnection. Keep the
            // last valid state (and the green badge) for 20 seconds.
            const recentlyConnected = lastSuccessfulClassSyncAt > 0 && (Date.now() - lastSuccessfulClassSyncAt) < 20000;
            if (recentlyConnected) {
                renderBadge(true, `${currentCourseTitle || 'CondaWeb'} · reconnexion…`);
            } else if (consecutiveSyncFailures >= 3) {
                isConnected = false;
                // The class can have been deleted or replaced. Drop only the
                // automatic association and resolve it again five seconds
                // later; the teacher never has to enter an ID.
                hasAutoConnected = false;
                activeClassId = '';
                activeClassName = '';
                nextAutoConnectAt = Date.now() + 5000;
                renderBadge(false, 'Reconnexion automatique…');
            }
        }
        } finally {
            syncInFlight = false;
        }
    }

    // 6. Rendu des calques visuels sans innerHTML (conforme Trusted Types de Google Docs)
    function renderAllOverlays() {
        const root = ensureOverlayRoot();
        const displayCourse = currentCourseTitle ? (currentCourseTitle.length > 20 ? currentCourseTitle.slice(0, 18) + '…' : currentCourseTitle) : '';
        const badgeText = displayCourse ? `${displayCourse} (${activeClassName || 'Actif'})` : (activeClassName || 'CondaWeb Connecté');
  if (presentationAssociationMissing) {
    showPresentationUnlinkedBadge();
  } else {
    renderBadge(isConnected, badgeText);
  }
        renderAlerts(root);
        renderHourWarnings(root);
        // Les animations et vidéos sont désormais entièrement gérées par
        // Google Slides. L'extension ne doit jamais monter un lecteur ou
        // intercepter leur lecture : elle se limite au plan, aux contrôles
        // choisis explicitement et aux notifications de notes.
        renderClassPlanModal(root);
        renderGoogleControlTools(root);
        renderTimerWidget(root);
    }

    function renderGoogleControlTools(root) {
        const existingControlCard = root.querySelector('.conda-slide-control-card');
        existingControlCard?.remove();

        let dock = root.querySelector('.conda-slide-control-dock');
        if (!dock) {
            dock = document.createElement('div');
            dock.className = 'conda-slide-control-dock';
            root.appendChild(dock);
        }

        let planButton = dock.querySelector('.conda-slide-plan-toggle');
        if (!planButton) {
            planButton = document.createElement('button');
            planButton.type = 'button';
            dock.appendChild(planButton);
        }
        planButton.onclick = () => { void togglePlanFromSlides(); };
        planButton.className = `conda-slide-plan-toggle ${currentClassroomState?.classPlanVisible === true ? 'active' : ''}`;
        planButton.textContent = currentClassroomState?.classPlanVisible === true ? '📍 PLAN ON' : '📍 PLAN';

        let addButton = dock.querySelector('.conda-slide-control-add');
        if (!addButton) {
            addButton = document.createElement('button');
            addButton.type = 'button';
            addButton.className = 'conda-slide-control-add';
            addButton.textContent = '📝 CONTRÔLE';
            addButton.title = 'Choisir un contrôle à attacher à la diapositive Google courante';
            addButton.onclick = () => { void openControlsMenu(); };
            dock.appendChild(addButton);
        }

        let timerButton = dock.querySelector('.conda-slide-timer-toggle');
        if (!timerButton) {
            timerButton = document.createElement('button');
            timerButton.type = 'button';
            timerButton.className = 'conda-slide-timer-toggle';
            timerButton.title = 'Minuteur 7 minutes modulable';
            dock.appendChild(timerButton);
        }
        // Toujours remplacer le handler : lors d'une mise à jour à chaud,
        // le bouton DOM peut survivre avec la fermeture de l'ancien script.
        // Deux états `timerWidgetOpen` concurrents faisaient alors clignoter
        // le panneau (ou le refermaient au prochain polling).
        timerButton.onclick = () => {
            timerWidgetOpen = !timerWidgetOpen;
            renderTimerWidget(root);
            updateTimerDockButton(timerButton);
        };
        updateTimerDockButton(timerButton);

        let notesButton = dock.querySelector('.conda-slide-notes-toggle');
        if (!notesButton) {
            notesButton = document.createElement('button');
            notesButton.type = 'button';
            notesButton.className = 'conda-slide-notes-toggle';
            notesButton.onclick = () => {
                scoreAlertsVisible = !scoreAlertsVisible;
                try {
                    localStorage.setItem('condaSlideScoreAlertsVisible', scoreAlertsVisible ? 'true' : 'false');
                } catch (_) {}
                updateNotesDockButton(notesButton);
                renderAlerts(root);
            };
            dock.appendChild(notesButton);
        }
        updateNotesDockButton(notesButton);

        const connectionBadge = root.querySelector('#conda-bridge-badge');
        if (isConnected && connectionBadge && connectionBadge.parentElement !== dock) {
            dock.appendChild(connectionBadge);
        }

        let menu = dock.querySelector('.conda-slide-control-menu');
        if (controlMenuOpen) {
            if (!menu) {
                menu = document.createElement('div');
                menu.className = 'conda-slide-control-menu';
                dock.appendChild(menu);
            }
            // Update menu contents only if needed, but for simplicity here we can rebuild the menu
            // since it's only open when the user explicitly clicks the button.
            while (menu.firstChild) menu.removeChild(menu.firstChild);
            if (!controlMenuRows.length) {
                const empty = document.createElement('span');
                empty.textContent = 'Aucun contrôle actif pour cette classe';
                menu.appendChild(empty);
            }
            controlMenuRows.forEach((control) => {
                const choice = document.createElement('button');
                choice.type = 'button';
                choice.textContent = String(control.title || 'Contrôle');
                choice.onclick = () => { void openSelectedControl(control); };
                menu.appendChild(choice);
            });
        } else if (menu) {
            menu.remove();
        }

        let classMenu = dock.querySelector('.conda-slide-class-menu');
        if (classMenuOpen) {
            if (!classMenu) {
                classMenu = document.createElement('div');
                classMenu.className = 'conda-slide-class-menu';
                dock.appendChild(classMenu);
            }
            while (classMenu.firstChild) classMenu.removeChild(classMenu.firstChild);

            const title = document.createElement('div');
            title.className = 'conda-slide-class-menu-title';
            title.textContent = 'Sélectionner une classe :';
            classMenu.appendChild(title);

            if (!classMenuRows.length) {
                const empty = document.createElement('span');
                empty.className = 'conda-slide-class-menu-empty';
                empty.textContent = 'Aucune classe trouvée';
                classMenu.appendChild(empty);
            } else {
                classMenuRows.forEach((cls) => {
                    const choice = document.createElement('button');
                    choice.type = 'button';
                    const isSelected = String(cls._id || cls.id) === String(activeClassId);
                    choice.className = `conda-class-choice-btn ${isSelected ? 'is-active' : ''}`;
                    choice.textContent = `${cls.name || cls.title || 'Classe'}${isSelected ? ' ✓' : ''}`;
                    choice.onclick = (e) => {
                        e.stopPropagation();
                        void selectAnotherClass(cls);
                    };
                    classMenu.appendChild(choice);
                });
            }
        } else if (classMenu) {
            classMenu.remove();
        }
    }

    // ==========================================
    // MINUTEUR / TIMER D'EXTENSION (7 MIN DEFAUT)
    // ==========================================
    let timerTotalSeconds = 420; // 7 minutes par défaut
    let timerRemainingSeconds = 420;
    let timerIsRunning = false;
    let timerIntervalId = null;
    let timerWidgetOpen = false;
    let timerWidgetMinimized = false;
    try {
        timerWidgetMinimized = localStorage.getItem('condaSlideTimerMinimized') === 'true';
    } catch (_) {}
    let scoreAlertsVisible = true;
    try {
        const savedAlertsVisible = localStorage.getItem('condaSlideScoreAlertsVisible');
        if (savedAlertsVisible !== null) {
            scoreAlertsVisible = savedAlertsVisible === 'true';
        }
    } catch (_) {}
    let timerAlarmPlaying = false;
    let timerAlarmIntervalId = null;
    let timerAudioCtx = null;
    let isEditingTimerMinutes = false;

    function updateNotesDockButton(btn) {
        if (!btn) {
            const root = overlayRoot;
            btn = root?.querySelector?.('.conda-slide-notes-toggle');
        }
        if (!btn) return;
        if (scoreAlertsVisible) {
            btn.className = 'conda-slide-notes-toggle active';
            btn.textContent = '🔔 NOTES ON';
            btn.title = 'Évolutions de notes affichées sur l’écran · Cliquer pour masquer';
        } else {
            btn.className = 'conda-slide-notes-toggle off';
            btn.textContent = '🔕 NOTES OFF';
            btn.title = 'Évolutions de notes masquées sur l’écran · Cliquer pour afficher';
        }
    }

    function getTimerAudioContext() {
        try {
            if (!timerAudioCtx) {
                const AudioContextClass = window.AudioContext || window.webkitAudioContext;
                if (AudioContextClass) {
                    timerAudioCtx = new AudioContextClass();
                }
            }
            if (timerAudioCtx && timerAudioCtx.state === 'suspended') {
                timerAudioCtx.resume().catch(() => {});
            }
        } catch (_) {}
        return timerAudioCtx;
    }

    function playTimerChime() {
        try {
            const ctx = getTimerAudioContext();
            if (!ctx) return;
            const now = ctx.currentTime;
            // Carillon harmonieux et distinct (3 notes A5, D6, F6)
            const notes = [
                { freq: 880, start: 0, dur: 0.22 },
                { freq: 1174.66, start: 0.14, dur: 0.28 },
                { freq: 1396.91, start: 0.30, dur: 0.45 }
            ];
            notes.forEach(({ freq, start, dur }) => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, now + start);
                gain.gain.setValueAtTime(0.28, now + start);
                gain.gain.exponentialRampToValueAtTime(0.001, now + start + dur);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now + start);
                osc.stop(now + start + dur);
            });
        } catch (e) {
            console.warn('[CondaWeb Bridge Timer] alarme audio:', e);
        }
    }

    function triggerTimerAlarm() {
        timerAlarmPlaying = true;
        let playCount = 0;
        playTimerChime();
        if (timerAlarmIntervalId) clearInterval(timerAlarmIntervalId);
        timerAlarmIntervalId = setInterval(() => {
            playCount += 1;
            if (playCount >= 5) {
                clearInterval(timerAlarmIntervalId);
                timerAlarmIntervalId = null;
            } else {
                playTimerChime();
            }
        }, 1200);
    }

    function stopTimerAlarm() {
        timerAlarmPlaying = false;
        if (timerAlarmIntervalId) {
            clearInterval(timerAlarmIntervalId);
            timerAlarmIntervalId = null;
        }
    }

    function formatTimerTime(sec) {
        const s = Math.max(0, Math.floor(sec));
        const mins = Math.floor(s / 60);
        const secs = s % 60;
        return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }

    function initTimerLoopIfNeeded() {
        if (timerIntervalId) return;
        timerIntervalId = setInterval(() => {
            if (timerIsRunning) {
                if (timerRemainingSeconds > 0) {
                    timerRemainingSeconds -= 1;
                    if (timerRemainingSeconds === 0) {
                        timerIsRunning = false;
                        timerWidgetOpen = true; // S'assurer que le widget est visible quand le temps expire
                        triggerTimerAlarm();
                    }
                } else {
                    timerIsRunning = false;
                }
            }
            updateTimerDisplay();
            updateTimerDockButton();
        }, 1000);
    }

    function updateTimerDockButton(targetButton) {
        const root = overlayRoot;
        const btn = targetButton || root?.querySelector('.conda-slide-timer-toggle');
        if (!btn) return;
        if (timerAlarmPlaying) {
            btn.textContent = '🔔 00:00 !';
            btn.className = 'conda-slide-timer-toggle alarm-ringing';
        } else if (timerIsRunning) {
            btn.textContent = `⏱️ ${formatTimerTime(timerRemainingSeconds)}`;
            btn.className = 'conda-slide-timer-toggle active';
        } else if (timerWidgetOpen) {
            btn.textContent = `⏱️ ${formatTimerTime(timerRemainingSeconds)}`;
            btn.className = 'conda-slide-timer-toggle active';
        } else {
            const minLabel = Math.round(timerTotalSeconds / 60);
            btn.textContent = `⏱️ TIMER (${minLabel}m)`;
            btn.className = 'conda-slide-timer-toggle';
        }
    }

    function updateTimerDisplay() {
        const root = overlayRoot;
        if (!root) return;
        const widget = root.querySelector('.conda-slide-timer-widget');
        if (!widget) {
            if (timerWidgetOpen) renderTimerWidget(root);
            return;
        }
        if (!timerWidgetOpen) {
            widget.remove();
            return;
        }

        const minInput = widget.querySelector('.conda-timer-min-input');
        const secDigits = widget.querySelector('.conda-timer-sec-digits');
        const colonEl = widget.querySelector('.conda-timer-colon');

        const s = Math.max(0, Math.floor(timerRemainingSeconds));
        const mins = Math.floor(s / 60);
        const secs = s % 60;

        if (minInput) {
            const isEditing = isEditingTimerMinutes || (document.activeElement === minInput);
            if (!isEditing) {
                minInput.value = String(mins).padStart(2, '0');
            }
        }
        if (secDigits) {
            secDigits.textContent = String(secs).padStart(2, '0');
        }

        const digitsColor = timerAlarmPlaying ? '#ef4444' : (timerIsRunning ? '#38bdf8' : '#f8fafc');
        if (minInput) minInput.style.color = digitsColor;
        if (secDigits) secDigits.style.color = digitsColor;
        if (colonEl) colonEl.style.color = digitsColor;

        const presetBtns = widget.querySelectorAll('.conda-timer-preset-btn');
        presetBtns.forEach(btn => {
            const sec = parseInt(btn.dataset.sec, 10);
            if (sec === timerTotalSeconds && !timerIsRunning) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        const statusEl = widget.querySelector('.conda-timer-status');
        if (statusEl) {
            if (timerAlarmPlaying) {
                statusEl.textContent = '🔔 TEMPS ÉCOULÉ !';
                statusEl.style.color = '#f87171';
            } else if (timerIsRunning) {
                statusEl.textContent = 'Décompte en cours…';
                statusEl.style.color = '#38bdf8';
            } else if (timerRemainingSeconds === 0) {
                statusEl.textContent = 'Terminé';
                statusEl.style.color = '#94a3b8';
            } else {
                statusEl.textContent = 'Prêt';
                statusEl.style.color = '#94a3b8';
            }
        }

        const startBtn = widget.querySelector('.conda-timer-start-btn');
        if (startBtn) {
            if (timerIsRunning) {
                startBtn.textContent = '⏸ PAUSE';
                startBtn.style.background = '#d97706';
            } else {
                startBtn.textContent = '▶ DÉMARRER';
                startBtn.style.background = '#16a34a';
            }
        }

        const stopAlarmBtn = widget.querySelector('.conda-timer-stop-alarm-btn');
        if (stopAlarmBtn) {
            stopAlarmBtn.style.display = timerAlarmPlaying ? 'block' : 'none';
        }

        if (timerAlarmPlaying) {
            widget.classList.add('alarm-ringing');
        } else {
            widget.classList.remove('alarm-ringing');
        }
    }

    function restoreTimerWidgetPosition(widget) {
        try {
            const saved = JSON.parse(localStorage.getItem('condaSlideTimerPosition') || sessionStorage.getItem('condaSlideTimerPosition') || 'null');
            if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
                const w = widget.offsetWidth || (timerWidgetMinimized ? 205 : 310);
                const h = widget.offsetHeight || 120;
                const maxLeft = Math.max(0, window.innerWidth - w);
                const maxTop = Math.max(0, window.innerHeight - h);
                widget.style.left = `${Math.min(maxLeft, Math.max(0, saved.left))}px`;
                widget.style.top = `${Math.min(maxTop, Math.max(0, saved.top))}px`;
                widget.style.right = 'auto';
                return;
            }
        } catch (_) {}
        const defaultW = widget.offsetWidth || (timerWidgetMinimized ? 205 : 310);
        const defaultLeft = Math.max(10, window.innerWidth - defaultW - 20);
        widget.style.left = `${defaultLeft}px`;
        widget.style.top = '18px';
        widget.style.right = 'auto';
    }

    function enableTimerWidgetDrag(widget, header) {
        if (!header) return;

        let dragStart = null;
        let lastPointerId = null;

        const onPointerMove = (event) => {
            if (!dragStart) return;
            event.preventDefault();
            const w = widget.offsetWidth || (timerWidgetMinimized ? 205 : 310);
            const h = widget.offsetHeight || 70;
            const maxLeft = Math.max(0, window.innerWidth - w);
            const maxTop = Math.max(0, window.innerHeight - h);
            const newLeft = Math.min(maxLeft, Math.max(0, dragStart.left + (event.clientX - dragStart.x)));
            const newTop = Math.min(maxTop, Math.max(0, dragStart.top + (event.clientY - dragStart.y)));
            widget.style.left = `${newLeft}px`;
            widget.style.top = `${newTop}px`;
            widget.style.right = 'auto';
        };

        const onPointerEnd = () => {
            if (dragStart) {
                try {
                    const rect = widget.getBoundingClientRect();
                    localStorage.setItem('condaSlideTimerPosition', JSON.stringify({
                        left: Math.round(rect.left),
                        top: Math.round(rect.top)
                    }));
                } catch (_) {}
            }
            dragStart = null;
            try {
                if (lastPointerId !== null && header.hasPointerCapture && header.hasPointerCapture(lastPointerId)) {
                    header.releasePointerCapture(lastPointerId);
                }
            } catch (_) {}
            lastPointerId = null;
            window.removeEventListener('pointermove', onPointerMove, true);
            window.removeEventListener('pointerup', onPointerEnd, true);
            window.removeEventListener('pointercancel', onPointerEnd, true);
            window.removeEventListener('mousemove', onPointerMove, true);
            window.removeEventListener('mouseup', onPointerEnd, true);
        };

        header.onpointerdown = (event) => {
            if (event.target?.closest?.('button') || event.target?.closest?.('input')) return;
            event.preventDefault();
            event.stopPropagation();

            const rect = widget.getBoundingClientRect();
            widget.style.left = `${rect.left}px`;
            widget.style.top = `${rect.top}px`;
            widget.style.right = 'auto';

            dragStart = {
                x: event.clientX,
                y: event.clientY,
                left: rect.left,
                top: rect.top
            };
            lastPointerId = event.pointerId;

            try {
                header.setPointerCapture?.(event.pointerId);
            } catch (_) {}

            window.addEventListener('pointermove', onPointerMove, true);
            window.addEventListener('pointerup', onPointerEnd, true);
            window.addEventListener('pointercancel', onPointerEnd, true);
            window.addEventListener('mousemove', onPointerMove, true);
            window.addEventListener('mouseup', onPointerEnd, true);
        };

        header.onpointermove = onPointerMove;
        header.onpointerup = onPointerEnd;
        header.onpointercancel = onPointerEnd;

        // Fallback pour mousedown
        header.onmousedown = (event) => {
            if (event.target?.closest?.('button') || event.target?.closest?.('input')) return;
            if (dragStart) return;
            event.preventDefault();
            event.stopPropagation();

            const rect = widget.getBoundingClientRect();
            widget.style.left = `${rect.left}px`;
            widget.style.top = `${rect.top}px`;
            widget.style.right = 'auto';

            dragStart = {
                x: event.clientX,
                y: event.clientY,
                left: rect.left,
                top: rect.top
            };

            window.addEventListener('mousemove', onPointerMove, true);
            window.addEventListener('mouseup', onPointerEnd, true);
        };
    }

    function renderTimerWidget(root) {
        initTimerLoopIfNeeded();
        let widget = root.querySelector('.conda-slide-timer-widget');
        if (!timerWidgetOpen) {
            if (widget) widget.remove();
            return;
        }

        const isNew = !widget;
        if (isNew) {
            widget = document.createElement('div');
            widget.className = 'conda-slide-timer-widget';
            root.appendChild(widget);
            restoreTimerWidgetPosition(widget);
        }

        if (timerWidgetMinimized) {
            widget.classList.add('minimized');
        } else {
            widget.classList.remove('minimized');
        }

        // La synchronisation CondaWeb passe toutes les secondes. Ne jamais
        // reconstruire le minuteur déjà monté : cela détruisait l'input actif,
        // faisait clignoter son focus et empêchait la saisie des minutes.
        if (!isNew) {
            updateTimerDisplay();
            return;
        }

        while (widget.firstChild) widget.removeChild(widget.firstChild);

        // Header (Draggable)
        const header = document.createElement('div');
        header.className = 'conda-timer-header';
        header.title = 'Glisser pour déplacer le minuteur sur l\'écran';

        const title = document.createElement('span');
        title.className = 'conda-timer-title';
        title.textContent = '⏱️ MINUTEUR ';
        const dragHint = document.createElement('small');
        dragHint.className = 'conda-timer-drag-hint';
        dragHint.textContent = '⋮⋮';
        title.appendChild(dragHint);

        const headerBtns = document.createElement('div');
        headerBtns.className = 'conda-timer-header-btns';

        const minBtn = document.createElement('button');
        minBtn.type = 'button';
        minBtn.className = 'conda-timer-min-btn';
        minBtn.textContent = timerWidgetMinimized ? '□' : '—';
        minBtn.title = timerWidgetMinimized ? 'Agrandir la fenêtre (mode complet)' : 'Réduire la taille (mode compact)';
        minBtn.onclick = (e) => {
            e.stopPropagation();
            timerWidgetMinimized = !timerWidgetMinimized;
            try {
                localStorage.setItem('condaSlideTimerMinimized', timerWidgetMinimized ? 'true' : 'false');
            } catch (_) {}
            widget.style.width = '';
            widget.style.height = '';
            renderTimerWidget(root);
        };
        minBtn.onpointerdown = (e) => e.stopPropagation();

        const closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'conda-timer-close-btn';
        closeBtn.textContent = '✕';
        closeBtn.title = 'Fermer le panneau (le minuteur continue)';
        closeBtn.onclick = (e) => {
            e.stopPropagation();
            timerWidgetOpen = false;
            widget.remove();
            updateTimerDockButton();
        };
        closeBtn.onpointerdown = (e) => e.stopPropagation();

        headerBtns.append(minBtn, closeBtn);
        header.append(title, headerBtns);
        widget.appendChild(header);
        enableTimerWidgetDrag(widget, header);

        // Digital Display
        const displayBox = document.createElement('div');
        displayBox.className = 'conda-timer-display';

        const digits = document.createElement('div');
        digits.className = 'conda-timer-digits';

        const minInput = document.createElement('input');
        minInput.type = 'text';
        minInput.inputMode = 'numeric';
        minInput.maxLength = 3;
        minInput.className = 'conda-timer-min-input';
        const initialMin = Math.floor(Math.max(0, timerRemainingSeconds) / 60);
        minInput.value = String(initialMin).padStart(2, '0');
        minInput.title = 'Entrer les minutes au clavier (ex: 12)';

        minInput.addEventListener('pointerdown', (e) => e.stopPropagation());
        minInput.addEventListener('mousedown', (e) => e.stopPropagation());
        minInput.addEventListener('click', (e) => e.stopPropagation());

        minInput.addEventListener('focus', () => {
            isEditingTimerMinutes = true;
            setTimeout(() => {
                try { minInput.select(); } catch (_) {}
            }, 10);
        });

        const commitMinutes = () => {
            isEditingTimerMinutes = false;
            const cleaned = (minInput.value || '').replace(/[^0-9]/g, '');
            if (cleaned === '') {
                const s = Math.max(0, Math.floor(timerRemainingSeconds));
                minInput.value = String(Math.floor(s / 60)).padStart(2, '0');
                return;
            }
            const val = parseInt(cleaned, 10);
            if (!Number.isFinite(val) || val < 0) {
                const s = Math.max(0, Math.floor(timerRemainingSeconds));
                minInput.value = String(Math.floor(s / 60)).padStart(2, '0');
                return;
            }
            const newMin = Math.min(999, Math.max(0, val));
            stopTimerAlarm();
            const currentSec = Math.max(0, Math.floor(timerRemainingSeconds)) % 60;
            if (timerIsRunning) {
                timerRemainingSeconds = (newMin * 60) + currentSec;
                timerTotalSeconds = Math.max(timerTotalSeconds, timerRemainingSeconds);
            } else {
                timerTotalSeconds = (newMin * 60) + currentSec;
                timerRemainingSeconds = timerTotalSeconds;
            }
            minInput.value = String(newMin).padStart(2, '0');
            updateTimerDisplay();
            updateTimerDockButton();
        };

        minInput.addEventListener('input', () => {
            const filtered = minInput.value.replace(/[^0-9]/g, '');
            if (minInput.value !== filtered) {
                minInput.value = filtered;
            }
            if (minInput.value.length > 3) {
                minInput.value = minInput.value.slice(0, 3);
            }
            if (minInput.value.length > 0) {
                const val = parseInt(minInput.value, 10);
                if (Number.isFinite(val) && val >= 0) {
                    const newMin = Math.min(999, val);
                    stopTimerAlarm();
                    const currentSec = Math.max(0, Math.floor(timerRemainingSeconds)) % 60;
                    if (timerIsRunning) {
                        timerRemainingSeconds = (newMin * 60) + currentSec;
                        timerTotalSeconds = Math.max(timerTotalSeconds, timerRemainingSeconds);
                    } else {
                        timerTotalSeconds = (newMin * 60) + currentSec;
                        timerRemainingSeconds = timerTotalSeconds;
                    }
                    updateTimerDockButton();
                }
            }
        });

        minInput.addEventListener('change', commitMinutes);
        minInput.addEventListener('blur', commitMinutes);

        const stopKeyNav = (e) => {
            e.stopPropagation();
            if (e.key === 'Enter' || e.key === 'Escape') {
                e.preventDefault();
                minInput.blur();
            }
        };
        minInput.addEventListener('keydown', stopKeyNav, true);
        minInput.addEventListener('keyup', (e) => e.stopPropagation(), true);
        minInput.addEventListener('keypress', (e) => e.stopPropagation(), true);

        const colon = document.createElement('span');
        colon.className = 'conda-timer-colon';
        colon.textContent = ':';

        const secDigits = document.createElement('span');
        secDigits.className = 'conda-timer-sec-digits';
        const initialSec = Math.max(0, Math.floor(timerRemainingSeconds)) % 60;
        secDigits.textContent = String(initialSec).padStart(2, '0');

        digits.append(minInput, colon, secDigits);

        const status = document.createElement('div');
        status.className = 'conda-timer-status';
        status.textContent = timerAlarmPlaying ? '🔔 TEMPS ÉCOULÉ !' : (timerIsRunning ? 'Décompte en cours…' : 'Prêt');

        displayBox.append(digits, status);
        widget.appendChild(displayBox);

        // Presets (1m, 2m, 3m, 5m, 7m, 10m, 15m, 20m)
        const presetsRow = document.createElement('div');
        presetsRow.className = 'conda-timer-presets-row';

        const presets = [
            { label: '1m', sec: 60 },
            { label: '2m', sec: 120 },
            { label: '3m', sec: 180 },
            { label: '5m', sec: 300 },
            { label: '7m', sec: 420 },
            { label: '10m', sec: 600 },
            { label: '15m', sec: 900 },
            { label: '20m', sec: 1200 }
        ];

        presets.forEach(({ label, sec }) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.dataset.sec = String(sec);
            btn.className = `conda-timer-preset-btn ${timerTotalSeconds === sec ? 'active' : ''}`;
            btn.textContent = label;
            btn.onclick = () => {
                stopTimerAlarm();
                timerTotalSeconds = sec;
                timerRemainingSeconds = sec;
                timerIsRunning = false;
                renderTimerWidget(root);
                updateTimerDockButton();
            };
            presetsRow.appendChild(btn);
        });
        widget.appendChild(presetsRow);

        // Modulation Buttons (-2m, -1m, +1m, +2m)
        const modRow = document.createElement('div');
        modRow.className = 'conda-timer-mod-row';

        const modButtons = [
            { label: '- 2m', delta: -120, is2m: true, title: 'Retirer 2 minutes' },
            { label: '- 1m', delta: -60, is2m: false, title: 'Retirer 1 minute' },
            { label: '+ 1m', delta: +60, is2m: false, title: 'Ajouter 1 minute' },
            { label: '+ 2m', delta: +120, is2m: true, title: 'Ajouter 2 minutes' }
        ];

        modButtons.forEach(({ label, delta, is2m, title }) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = `conda-timer-mod-btn ${is2m ? 'conda-timer-mod-2m' : 'conda-timer-mod-1m'}`;
            btn.textContent = label;
            btn.title = title;
            btn.onclick = () => {
                stopTimerAlarm();
                if (timerIsRunning) {
                    timerRemainingSeconds = Math.max(0, timerRemainingSeconds + delta);
                    if (timerRemainingSeconds === 0) {
                        timerIsRunning = false;
                        triggerTimerAlarm();
                    }
                } else {
                    timerTotalSeconds = Math.max(0, timerTotalSeconds + delta);
                    timerRemainingSeconds = timerTotalSeconds;
                }
                updateTimerDisplay();
                updateTimerDockButton();
            };
            modRow.appendChild(btn);
        });
        widget.appendChild(modRow);

        // Actions Row (Start/Pause, Reset)
        const actionsRow = document.createElement('div');
        actionsRow.className = 'conda-timer-actions-row';

        const startBtn = document.createElement('button');
        startBtn.type = 'button';
        startBtn.className = 'conda-timer-start-btn';
        startBtn.textContent = timerIsRunning ? '⏸ PAUSE' : '▶ DÉMARRER';
        startBtn.style.background = timerIsRunning ? '#d97706' : '#16a34a';
        startBtn.onclick = () => {
            getTimerAudioContext();
            stopTimerAlarm();
            if (timerIsRunning) {
                timerIsRunning = false;
            } else {
                if (timerRemainingSeconds <= 0) {
                    timerRemainingSeconds = timerTotalSeconds || 420;
                }
                timerIsRunning = true;
            }
            updateTimerDisplay();
            updateTimerDockButton();
        };

        const resetBtn = document.createElement('button');
        resetBtn.type = 'button';
        resetBtn.className = 'conda-timer-reset-btn';
        resetBtn.textContent = '↺ RÉINIT';
        resetBtn.title = 'Réinitialiser le minuteur';
        resetBtn.onclick = () => {
            stopTimerAlarm();
            timerIsRunning = false;
            timerRemainingSeconds = timerTotalSeconds || 420;
            updateTimerDisplay();
            updateTimerDockButton();
        };

        actionsRow.append(startBtn, resetBtn);
        widget.appendChild(actionsRow);

        // Stop Alarm Button (only shown when alarm is ringing)
        const stopAlarmBtn = document.createElement('button');
        stopAlarmBtn.type = 'button';
        stopAlarmBtn.className = 'conda-timer-stop-alarm-btn';
        stopAlarmBtn.textContent = '🔕 ARRÊTER L\'ALARME';
        stopAlarmBtn.style.display = timerAlarmPlaying ? 'block' : 'none';
        stopAlarmBtn.onclick = () => {
            stopTimerAlarm();
            updateTimerDisplay();
            updateTimerDockButton();
        };
        widget.appendChild(stopAlarmBtn);

        updateTimerDisplay();
    }

    function restoreBadgePosition(badge) {
        try {
            const position = JSON.parse(sessionStorage.getItem('condaBridgeBadgePosition') || 'null');
            if (!position || !Number.isFinite(position.left) || !Number.isFinite(position.top)) return;
            badge.style.left = `${Math.max(0, position.left)}px`;
            badge.style.top = `${Math.max(0, position.top)}px`;
        } catch (_) {
            // A malformed saved position must never prevent the bridge UI.
        }
    }

    function enableBadgeDrag(badge) {
        if (badge.dataset.dragReady === '1') return;
        badge.dataset.dragReady = '1';
        const grip = badge.querySelector('.conda-bridge-drag-handle');
        if (!grip) return;
        grip.addEventListener('pointerdown', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const rect = badge.getBoundingClientRect();
            const offsetX = event.clientX - rect.left;
            const offsetY = event.clientY - rect.top;
            grip.setPointerCapture?.(event.pointerId);
            const move = (moveEvent) => {
                const maxLeft = Math.max(0, window.innerWidth - rect.width);
                const maxTop = Math.max(0, window.innerHeight - rect.height);
                badge.style.left = `${Math.min(maxLeft, Math.max(0, moveEvent.clientX - offsetX))}px`;
                badge.style.top = `${Math.min(maxTop, Math.max(0, moveEvent.clientY - offsetY))}px`;
            };
            const finish = () => {
                window.removeEventListener('pointermove', move, true);
                window.removeEventListener('pointerup', finish, true);
                const nextRect = badge.getBoundingClientRect();
                sessionStorage.setItem('condaBridgeBadgePosition', JSON.stringify({ left: nextRect.left, top: nextRect.top }));
                console.info('[CondaWeb Bridge] badge déplacé', { left: Math.round(nextRect.left), top: Math.round(nextRect.top) });
            };
            window.addEventListener('pointermove', move, true);
            window.addEventListener('pointerup', finish, true);
        });
    }

    // Badge d'état flottant en haut à gauche (sans innerHTML)
    function renderBadge(connected, text) {
        const root = ensureOverlayRoot();
        let badge = document.getElementById('conda-bridge-badge');
        if (connected) badgeDismissedForPage = false;
        if (badgeDismissedForPage && !connected) {
            badge?.remove();
            return;
        }
        if (!badge) {
            badge = document.createElement('div');
            badge.id = 'conda-bridge-badge';
            badge.className = 'conda-bridge-badge';

            const grip = document.createElement('span');
            grip.className = 'conda-bridge-drag-handle';
            grip.title = 'Déplacer le bouton';
            grip.setAttribute('aria-label', 'Déplacer le bouton CondaWeb');
            grip.textContent = '⋮⋮';
            badge.appendChild(grip);

            const dot = document.createElement('div');
            dot.className = 'conda-bridge-dot';
            const dotColor = connected ? '#10b981' : '#ef4444';
            dot.style.cssText = `width: 10px; height: 10px; border-radius: 50%; background: ${dotColor}; box-shadow: 0 0 10px ${dotColor}; flex-shrink: 0;`;
            badge.appendChild(dot);

            const label = document.createElement('span');
            label.className = 'conda-bridge-label';
            label.textContent = `⚡ ${text}`;
            badge.appendChild(label);

            const dismiss = document.createElement('button');
            dismiss.type = 'button';
            dismiss.className = 'conda-bridge-dismiss';
            dismiss.title = 'Masquer le bouton de connexion';
            dismiss.setAttribute('aria-label', 'Masquer le bouton de connexion');
            dismiss.textContent = '×';
            badge.appendChild(dismiss);
            root.appendChild(badge);
            restoreBadgePosition(badge);
            enableBadgeDrag(badge);
            console.log('[CondaWeb Bridge] ✅ Badge affiché à l\'écran (haut-gauche).');

        } else {
            const dot = badge.querySelector('.conda-bridge-dot');
            if (dot) {
                dot.style.background = connected ? '#10b981' : '#ef4444';
                dot.style.boxShadow = connected ? '0 0 10px #10b981' : '0 0 10px #ef4444';
            }
            const label = badge.querySelector('.conda-bridge-label');
            if (label) {
                label.textContent = `⚡ ${text}`;
            }
        }
        badge.classList.toggle('is-connected', Boolean(connected));
        badge.title = connected
            ? `Classe : ${activeClassName || 'Active'} · Cliquer pour changer de classe`
            : 'Non connecté · Cliquer pour reconnecter et synchroniser';
        // A failed reconnection must put the badge back in the floating area.
        // appendChild moves the existing node without creating a duplicate.
        if (!connected && badge.parentElement !== root) root.appendChild(badge);
    }

    // Alertes élèves (sans innerHTML)
    function renderAlerts(root) {
        let stack = root.querySelector('.conda-alerts-stack');
        if (!stack) {
            stack = document.createElement('div');
            stack.className = 'conda-alerts-stack';
            root.appendChild(stack);
        }
        if (!scoreAlertsVisible) {
            stack.style.display = 'none';
            return;
        }
        stack.style.display = '';

        const alerts = Array.isArray(currentClassroomState?.activeScoreAlerts)
            ? [...currentClassroomState.activeScoreAlerts]
            : [];
        // All new actions are written into activeScoreAlerts by the server.
        // Do not rebuild alerts from legacy fields here: those fields persist
        // across reloads and were replaying old pupils such as Pedro.
        const now = Date.now();
        alerts.forEach((alert, index) => {
            const createdAt = new Date(alert?.createdAt || 0).getTime();
            const alertId = String(alert?.id || `${createdAt}-${alert?.message || index}`);
            // A bridge poll can be delayed by Google Slides or by a slow
            // connection.  Five seconds made alerts disappear before their
            // first render.  Keep score changes readable for thirty seconds.
            const isExplicitReplay = replayableAlertIds.has(alertId);
            if (displayedAlertIds.has(alertId) || !createdAt || (!isExplicitReplay && Math.abs(now - createdAt) > 30000)) return;
            displayedAlertIds.add(alertId);
            replayableAlertIds.delete(alertId);
            const isNegative = alert.type === 'negative' || /(?:−|-|–)(?:0[,\.]5|1)/.test(String(alert.message || ''));
            const isWarning = !isNegative && (alert.isPenalty || ['warning', 'highlight'].includes(alert.type) || (alert.message && alert.message.toLowerCase().includes('avertissement')));
            const toast = document.createElement('div');
            toast.className = `conda-alert-toast ${isNegative ? 'negative' : (isWarning ? 'warning' : 'positive')}`;
            toast.dataset.alertId = alertId;

            const icon = document.createElement('div');
            icon.className = 'conda-alert-icon';
            icon.textContent = isNegative ? '📉' : (isWarning ? '⚠️' : '📈');
            toast.appendChild(icon);

            const body = document.createElement('div');
            body.className = 'conda-alert-body';

            const hasScoreChange = alert?.score !== null && alert?.score !== undefined && Number.isFinite(Number(alert?.score));
            if (hasScoreChange) {
                const nameSpan = document.createElement('strong');
                nameSpan.className = 'conda-alert-name';
                nameSpan.textContent = alert.message || alert.studentName || 'Élève';
                body.appendChild(nameSpan);

                const score = Number(alert.score);
                const scoreSpan = document.createElement('span');
                scoreSpan.className = 'conda-alert-score';
                scoreSpan.textContent = `${Number.isInteger(score) ? score : score.toFixed(1).replace('.', ',')} / 20`;
                body.appendChild(scoreSpan);
            } else {
                const title = document.createElement('strong');
                title.className = 'conda-alert-name';
                title.textContent = alert.type === 'highlight' ? 'ÉLÈVE APPELÉ' : (isNegative ? 'NOTE EN BAISSE' : (isWarning ? 'AVERTISSEMENT' : 'NOTE EN HAUSSE'));
                body.appendChild(title);

                const sub = document.createElement('span');
                sub.className = 'conda-alert-score';
                sub.textContent = alert.message || alert.studentName || '';
                if (sub.textContent) body.appendChild(sub);
            }

            toast.appendChild(body);
            const close = document.createElement('button');
            close.type = 'button';
            close.className = 'conda-alert-close';
            close.textContent = '×';
            close.title = 'Fermer cette notification';
            close.setAttribute('aria-label', 'Fermer cette notification');
            close.addEventListener('click', (event) => {
                event.preventDefault();
                event.stopPropagation();
                toast.remove();
            });
            toast.appendChild(close);
            stack.appendChild(toast);
            // Remains readable from the back of the classroom.  The alert is
            // still retained server-side for 30 seconds so a delayed bridge
            // can render it once, but this visible toast lasts ten seconds.
            window.setTimeout(() => toast.remove(), 10000);
        });
    }

    // Dettes persistantes, avertissements de l'heure et mémo-devoirs (sans innerHTML)
    function renderHourWarnings(root) {
        // Nettoie un éventuel ancien calque indépendant
        root.querySelector('.conda-class-notif-banner')?.remove();

        const warnings = Array.isArray(currentClassroomState?.activeHourWarnings) ? currentClassroomState.activeHourWarnings : [];
        const debts = Array.isArray(currentClassroomState?.activePersistentDebts) ? currentClassroomState.activePersistentDebts : [];
        const notif = currentClassroomState?.classNotification;

        const notices = [
            ...(notif?.text ? [{ noticeType: 'notif', text: notif.text }] : []),
            ...debts.map((row) => ({ ...row, noticeType: row.status || 'incomplete' })),
            ...warnings.map((row) => ({ ...row, noticeType: 'warning', expiresAt: row.expiresAt || '' }))
        ].filter((row) => row.noticeType === 'notif' || !dismissedPersistentNoticeIds.has(`${row.noticeType}:${row.studentId || row.name || ''}:${row.expiresAt || ''}`));
        let dock = root.querySelector('.conda-hour-warnings-dock');

        if (notices.length === 0) {
            if (dock) dock.remove();
            return;
        }

        if (!dock) {
            dock = document.createElement('div');
            dock.className = 'conda-hour-warnings-dock';
            root.appendChild(dock);
        }

        while (dock.firstChild) {
            dock.removeChild(dock.firstChild);
        }

        const title = document.createElement('div');
        title.className = 'conda-hour-warnings-title';
        title.textContent = 'À RÉGLER';
        dock.appendChild(title);
        const ul = document.createElement('ul');
        notices.forEach((row) => {
            const noticeId = row.noticeType === 'notif' ? 'class-notif' : `${row.noticeType}:${row.studentId || row.name || ''}:${row.expiresAt || ''}`;
            const li = document.createElement('li');
            li.className = `conda-persistent-notice ${row.noticeType}`;
            const label = document.createElement('span');
            if (row.noticeType === 'notif') {
                label.textContent = `🔔 Devoirs · ${row.text}`;
            } else {
                const prefix = row.noticeType === 'punishment' ? 'Punition · ' : (row.noticeType === 'warning' ? 'Avertissement · ' : 'Travail incomplet · ');
                const detail = row.text ? ` (${row.text})` : '';
                label.textContent = `${prefix}${row.name || row.studentName || ''}${detail}`;
            }
            li.appendChild(label);
            const close = document.createElement('button');
            close.type = 'button';
            close.textContent = '×';
            close.title = row.noticeType === 'notif' ? 'Valider et effacer ce devoir' : 'Masquer cette alerte';
            close.setAttribute('aria-label', close.title);
            close.addEventListener('click', async (event) => {
                event.preventDefault();
                event.stopPropagation();
                if (row.noticeType === 'notif') {
                    if (currentClassroomState) currentClassroomState.classNotification = null;
                    li.remove();
                    if (ul.children.length === 0 && dock) dock.remove();
                    if (activeClassId) {
                        try {
                            await callCondaApi(`/api/classroom/${encodeURIComponent(activeClassId)}/notification`, { method: 'DELETE' });
                        } catch (_) {}
                    }
                } else {
                    dismissedPersistentNoticeIds.add(noticeId);
                    renderHourWarnings(root);
                }
            });
            li.appendChild(close);
            ul.appendChild(li);
        });
        dock.appendChild(ul);
    }

    // Lecteur de vidéo / animation incrusté (sans innerHTML)
    function renderVideoModal(root) {
        const remote = currentRemoteState?.remote || {};
        const isVisible = remote.animationVisible === true;
        const isPlaying = remote.animationPlaying === true;
        const currentVideo = resolveCurrentVideo();
        let modal = root.querySelector('.conda-video-modal');

        if (!currentVideo) {
            if (modal) {
                const media = modal.querySelector('video, audio, iframe');
                try { media?.pause?.(); } catch (_) {}
                if (media?.tagName === 'IFRAME') media.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: 'pauseVideo', args: [] }), '*');
                modal.remove();
            }
            return;
        }

        const videoKey = String(currentVideo.id || currentVideo.url || `${currentVideo.name || ''}:${currentVideo.startSec || 0}:${currentVideo.endSec || 0}`);
        const mustBuild = !modal || modal.dataset.videoKey !== videoKey;
        if (!modal) {
            modal = document.createElement('div');
            modal.className = 'conda-video-modal';
            root.appendChild(modal);
        }
        // Garder le média monté et préchargé même quand l'animation est cachée.
        // Le téléphone reçoit ainsi l'état prêt avant le premier appui sur Lecture.
        modal.style.display = isVisible ? 'flex' : 'none';
        if (mustBuild) {
            modal.dataset.videoKey = videoKey;
            delete modal.dataset.finished;
            while (modal.firstChild) modal.removeChild(modal.firstChild);
            const isYoutube = currentVideo.sourceType === 'youtube' || /youtu(?:\.be|be\.com)/i.test(String(currentVideo.url || ''));
            const isAudio = String(currentVideo.sourceType || '').toLowerCase() === 'audio'
                || String(currentVideo.mimeType || '').toLowerCase().startsWith('audio/')
                || /\.(mp3|m4a|aac|wav|ogg|oga|flac)(?:[?#].*)?$/i.test(String(currentVideo.url || ''));
            const header = document.createElement('div');
            header.className = 'conda-video-modal-header';
            const title = document.createElement('span');
            title.textContent = `${isAudio ? '🎵' : '🎬'} ${currentVideo.title || currentVideo.name || 'Animation CondaWeb'}`;
            header.appendChild(title);
            const closeBtn = document.createElement('button');
            closeBtn.className = 'conda-video-modal-close';
            closeBtn.type = 'button';
            closeBtn.textContent = '×';
            closeBtn.onclick = () => {
                modal.remove();
                sendCourseCommand('animation_hide').catch(() => {});
            };
            header.appendChild(closeBtn);
            modal.appendChild(header);

            if (isYoutube) {
                let id = '';
                try {
                    const url = new URL(currentVideo.url);
                    id = url.hostname.includes('youtu.be') ? url.pathname.slice(1) : (url.searchParams.get('v') || url.pathname.match(/\/(?:embed|shorts)\/([^/?]+)/)?.[1] || '');
                } catch (_) {}
                const start = Math.max(0, Math.floor(Number(currentVideo.startSec || 0)));
                const end = Math.max(0, Math.floor(Number(currentVideo.endSec || 0)));
                const iframe = document.createElement('iframe');
                iframe.src = `https://www.youtube.com/embed/${encodeURIComponent(id)}?enablejsapi=1&controls=0&rel=0&playsinline=1&autoplay=${isPlaying ? 1 : 0}&start=${start}${end ? `&end=${end}` : ''}`;
                iframe.allow = 'autoplay; fullscreen';
                iframe.style.cssText = 'flex: 1; width: 100%; height: calc(100% - 40px); border: none;';
                iframe.addEventListener('load', () => {
                    reportBufferStatus(100, true);
                    iframe.contentWindow?.postMessage(JSON.stringify({ event: 'listening', id: videoKey }), '*');
                    if (!isPlaying) {
                        iframe.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: 'pauseVideo', args: [] }), '*');
                    }
                }, { once: true });
                modal.appendChild(iframe);
            } else {
                const media = document.createElement(isAudio ? 'audio' : 'video');
                media.src = currentVideo.url;
                media.autoplay = isPlaying;
                media.controls = false;
                media.preload = 'auto';
                if (!isAudio) media.playsInline = true;
                media.style.cssText = 'flex: 1; width: 100%; height: calc(100% - 40px); border: none; object-fit: contain;';
                media.addEventListener('loadedmetadata', () => {
                    media.currentTime = Math.max(0, Number(currentVideo.startSec || 0));
                    reportBufferStatus(25, false);
                });
                media.addEventListener('canplay', () => reportBufferStatus(70, true), { once: true });
                media.addEventListener('canplaythrough', () => reportBufferStatus(100, true), { once: true });
                media.addEventListener('timeupdate', () => {
                    const end = Math.max(0, Number(currentVideo.endSec || 0));
                    if (end > 0 && media.currentTime >= end && modal.dataset.finished !== '1') {
                        modal.dataset.finished = '1';
                        media.pause();
                        sendCourseCommand('sequence_finished', { closeAfterSequence: currentVideo.closeAfterSequence === true }).catch(() => {});
                    }
                });
                media.addEventListener('ended', () => {
                    if (modal.dataset.finished === '1') return;
                    modal.dataset.finished = '1';
                    sendCourseCommand('sequence_finished', { closeAfterSequence: currentVideo.closeAfterSequence === true }).catch(() => {});
                });
                modal.appendChild(media);
            }
        }

        const media = modal.querySelector('video, audio, iframe');
        if (media?.tagName === 'IFRAME') {
            const playVersion = Number(remote.playVersion || 0);
            const pauseVersion = Number(remote.pauseVersion || 0);
            if (isVisible && isPlaying && playVersion > lastHandledPlayVersion) {
                lastHandledPlayVersion = playVersion;
                media.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: 'playVideo', args: [] }), '*');
            } else if (!isPlaying && pauseVersion > lastHandledPauseVersion) {
                lastHandledPauseVersion = pauseVersion;
                media.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: 'pauseVideo', args: [] }), '*');
            }
        } else if (media) {
            if (isVisible && isPlaying && media.paused) media.play().catch(() => {});
            if ((!isVisible || !isPlaying) && !media.paused) media.pause();
        }
    }

    // L'API iframe YouTube publie son état par postMessage. Une fin de lecture
    // doit avancer d'une seule séquence, puis rester en pause jusqu'à la prochaine commande.
    window.addEventListener('message', (event) => {
        let payload = event.data;
        if (typeof payload === 'string') {
            try { payload = JSON.parse(payload); } catch (_) { return; }
        }
        if (!payload || typeof payload !== 'object') return;
        const modal = ensureOverlayRoot().querySelector('.conda-video-modal');
        const iframe = modal?.querySelector('iframe');
        if (!iframe || event.source !== iframe.contentWindow) return;
        const playerState = payload.event === 'onStateChange'
            ? Number(payload.info)
            : Number(payload.info?.playerState);
        if (playerState !== 0 || modal.dataset.finished === '1') return;
        modal.dataset.finished = '1';
        const currentVideo = resolveCurrentVideo();
        sendCourseCommand('sequence_finished', {
            closeAfterSequence: currentVideo?.closeAfterSequence === true
        }).catch(() => {});
    });

    // Plan de classe miroir (sans innerHTML)
    function renderClassPlanModal(root) {
        const hasClassPlanState = currentClassroomState && Object.prototype.hasOwnProperty.call(currentClassroomState, 'classPlanVisible');
        const isPlanVisible = hasClassPlanState
            ? currentClassroomState.classPlanVisible === true
            : currentRemoteState?.remote?.classPlanVisible === true;
        let modal = root.querySelector('.conda-class-plan-modal');

        if (!isPlanVisible) {
            if (modal) modal.remove();
            return;
        }

        const planStudents = Array.isArray(currentClassroomState?.planStudents) ? currentClassroomState.planStudents : [];
        const planRenderSignature = JSON.stringify({
            classId: String(currentClassroomState?._id || activeClassId || ''),
            cols: Number(currentClassroomState?.layout?.cols || 6),
            rows: Number(currentClassroomState?.layout?.rows || 5),
            students: planStudents.map((student) => [
                String(student?._id || student?.id || ''),
                Number(student?.seatX),
                Number(student?.seatY),
                String(student?.nickname || student?.firstName || ''),
                String(student?.lastName || ''),
                Number(student?.score)
            ])
        });
        if (modal?.dataset?.renderSignature === planRenderSignature) return;

        if (!modal) {
            modal = document.createElement('div');
            modal.className = 'conda-class-plan-modal';
            root.appendChild(modal);
        }
        modal.dataset.renderSignature = planRenderSignature;

        while (modal.firstChild) {
            modal.removeChild(modal.firstChild);
        }

        const header = document.createElement('div');
        header.style.cssText = 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex: 0 0 auto;';

        const title = document.createElement('h2');
        title.style.cssText = 'margin: 0; font-size: clamp(18px, 1.8vw, 26px); font-weight: 900; color: #38bdf8; letter-spacing: .02em;';
        title.textContent = '🗺️ PLAN DE CLASSE — VUE ÉLÈVES (MIROIR)';
        header.appendChild(title);

        const closeBtn = document.createElement('button');
        closeBtn.textContent = '✕ FERMER LE PLAN';
        closeBtn.style.cssText = 'background: #dc2626; border: 2px solid #ef4444; color: #fff; border-radius: 12px; padding: 8px 20px; cursor: pointer; font-size: 15px; font-weight: 900; box-shadow: 0 4px 14px rgba(220,38,38,.4); transition: transform .15s, background .15s;';
        closeBtn.onmouseover = () => { closeBtn.style.background = '#b91c1c'; closeBtn.style.transform = 'scale(1.03)'; };
        closeBtn.onmouseout = () => { closeBtn.style.background = '#dc2626'; closeBtn.style.transform = 'none'; };
        closeBtn.onclick = () => {
            if (currentClassroomState) {
                currentClassroomState.classPlanVisible = false;
            }
            modal.remove();
            renderAllOverlays();
            if (activeClassId) {
                callCondaApi(`/api/classroom/${encodeURIComponent(activeClassId)}/bridge-plan`, {
                    method: 'PUT',
                    body: { visible: false }
                }).catch(() => {});
            }
        };
        header.appendChild(closeBtn);
        modal.appendChild(header);

        const boardBar = document.createElement('div');
        boardBar.style.cssText = 'text-align: center; padding: 8px 14px; background: #0284c7; border-radius: 10px; margin-bottom: 12px; font-weight: 900; font-size: clamp(12px, 1.1vw, 16px); letter-spacing: .06em; color: #ffffff; text-transform: uppercase; box-shadow: 0 2px 10px rgba(2, 132, 199, 0.4); flex: 0 0 auto;';
        boardBar.textContent = '⬛ TABLEAU ET BUREAU DU PROFESSEUR (DEVANT) ⬛';
        modal.appendChild(boardBar);

        const cols = Math.max(1, Number(currentClassroomState?.layout?.cols || 6));
        const highestSeatRow = planStudents.reduce((max, student) => Math.max(max, Number(student?.seatY) + 1 || 0), 0);
        const rows = Math.max(1, Number(currentClassroomState?.layout?.rows || 5), highestSeatRow);
        const topStudentIds = new Set(planStudents
            .filter((student) => student?.score !== null && student?.score !== undefined && Number.isFinite(Number(student.score)))
            .sort((a, b) => Number(b.score) - Number(a.score))
            .slice(0, 4)
            .map((student) => String(student?._id || student?.id || '')));
        const grid = document.createElement('div');
        grid.style.cssText = `flex: 1; height: 100%; min-height: 0; display: grid; grid-template-columns: repeat(${cols}, minmax(0, 1fr)); grid-template-rows: repeat(${rows}, minmax(0, 1fr)); gap: 10px;`;
        modal.appendChild(grid);

        if (activeClassId) {
            while (grid.firstChild) grid.removeChild(grid.firstChild);

            // Indexer les élèves par position (seatX, seatY)
            const studentBySeat = new Map();
            planStudents.forEach((student) => {
                if (student?.seatX !== null && student?.seatY !== null
                    && Number.isFinite(Number(student.seatX)) && Number.isFinite(Number(student.seatY))) {
                    const sx = Math.max(0, Math.min(cols - 1, Number(student.seatX)));
                    const sy = Math.max(0, Math.min(rows - 1, Number(student.seatY)));
                    studentBySeat.set(`${sx},${sy}`, student);
                }
            });

            // Remplissage physique : 1 seul élément par case, SANS SUPERPOSITION
            for (let seatY = 0; seatY < rows; seatY += 1) {
                for (let seatX = 0; seatX < cols; seatX += 1) {
                    const student = studentBySeat.get(`${seatX},${seatY}`);
                    if (student) {
                        // Carte élève : fond blanc éclatant, texte noir net et contrasté
                        const card = document.createElement('div');
                        card.className = 'conda-plan-student-card';
                        const isTopStudent = topStudentIds.has(String(student?._id || student?.id || ''));
                        const seatBorder = isTopStudent ? '4px solid #2563eb' : '2px dashed #94a3b8';
                        card.style.cssText = `grid-column: ${cols - seatX}; grid-row: ${rows - seatY}; padding: 6px 10px; background: #ffffff !important; color: #000000 !important; border: ${seatBorder} !important; border-radius: 14px; text-align: center; display: flex; flex-direction: column; justify-content: center; align-items: center; min-width: 0; height: 100%; box-sizing: border-box; box-shadow: ${isTopStudent ? '0 0 0 2px rgba(37,99,235,.2), 0 4px 14px rgba(0,0,0,.35)' : '0 4px 14px rgba(0,0,0,.2)'};`;
                                    
                        const sName = document.createElement('strong');
                        sName.className = 'conda-plan-student-name';
                        sName.style.cssText = 'display: block; font-size: clamp(16px, 2.2vw, 32px); font-weight: 950; line-height: 1.15; color: #000000 !important; -webkit-text-fill-color: #000000 !important; opacity: 1 !important; text-shadow: none !important; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100%;';
                        sName.style.setProperty('color', '#000000', 'important');
                        sName.style.setProperty('-webkit-text-fill-color', '#000000', 'important');
                        sName.style.setProperty('opacity', '1', 'important');
                        sName.textContent = String(student.nickname || student.firstName || '').trim();
                        card.appendChild(sName);

                        const initial = document.createElement('span');
                        initial.className = 'conda-plan-student-initial';
                        initial.style.cssText = 'display: block; font-size: clamp(12px, 1.2vw, 18px); color: #000000 !important; -webkit-text-fill-color: #000000 !important; opacity: 1 !important; text-shadow: none !important; font-weight: 900; margin-top: 2px;';
                        initial.style.setProperty('color', '#000000', 'important');
                        initial.style.setProperty('-webkit-text-fill-color', '#000000', 'important');
                        initial.style.setProperty('opacity', '1', 'important');
                        initial.textContent = `${String(student.lastName || '').slice(0, 1)}.`;
                        card.appendChild(initial);

                        grid.appendChild(card);
                    } else {
                        // Place vide : bordure en tirets grise/bleutée, fond sombre translucide
                        const emptySeat = document.createElement('div');
                        emptySeat.className = 'conda-plan-empty-seat';
                        emptySeat.style.cssText = `grid-column: ${cols - seatX}; grid-row: ${rows - seatY}; background: rgba(30, 41, 59, 0.45); border: 2px dashed rgba(148, 163, 184, 0.4); border-radius: 14px; min-width: 0; height: 100%; box-sizing: border-box;`;
                        grid.appendChild(emptySeat);
                    }
                }
            }
        }
    }

    // Démarrage immédiat
    function init() {
        console.log('[CondaWeb Bridge] ⚡ init() appelé...');
        ensureOverlayRoot();
        renderBadge(false, 'Connexion à CondaWeb…');
        renderAllOverlays();
        syncWithCondaWeb();
    }

    // Observer pour ré-attacher si Google Slides supprime ou modifie l'arbre DOM
    domObserver = new MutationObserver(() => {
        if (bridgeStopped) return;
        const root = document.getElementById('condaweb-overlay-root');
        if (!root || !document.contains(root)) {
            console.log('[CondaWeb Bridge] Restauration du calque d\'overlay détaché...');
            ensureOverlayRoot();
            renderAllOverlays();
        }
    });

    try {
        domObserver.observe(document.documentElement, { childList: true, subtree: false });
        if (document.body) {
            domObserver.observe(document.body, { childList: true, subtree: false });
        }
    } catch (_) {}

    // Lancement immédiat et écoute des états
    init();
    // The classroom call is deliberately light and guarded by syncInFlight:
    // one request at a time, every 800 ms. This makes the Google Slides board
    // react to the phone almost immediately without creating request piles.
    syncTimerId = window.setInterval(syncWithCondaWeb, CLASSROOM_POLL_MS);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
        window.addEventListener('load', init);
    }
})();
